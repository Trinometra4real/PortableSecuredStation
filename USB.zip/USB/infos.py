__all_ = ["Session"]
helpCommand = {
    "help": "Show help for the commands to use",
    "cd" : "Change directory",
    "ls" : "List Directories and files",
    "exit" : "close this session"
}

if __name__ == '__main__':
    main()